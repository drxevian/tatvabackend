import express from 'express';
import { productApiHandlers, inquiryApiHandlers, contactApiHandlers } from '../api';

const router = express.Router();

//
// 🔹 PRODUCT ROUTES
//
router.get('/products', async (req, res) => {
  try {
    const products = await productApiHandlers.getAllProducts();
    res.json(products);
  } catch (error) {
    console.error('❌ Failed to fetch products:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

router.get('/products/:id', async (req, res) => {
  try {
    const product = await productApiHandlers.getProductById(req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  } catch (error) {
    console.error(`❌ Failed to fetch product ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to fetch product' });
  }
});

router.post('/products', async (req, res) => {
  try {
    console.log("🔄 Product creation request received:", req.body); // Added debug log
    const newProduct = await productApiHandlers.addProduct(req.body);
    res.status(201).json(newProduct);
  } catch (error) {
    console.error('❌ Failed to create product:', error.message); // More descriptive error log
    res.status(500).json({ error: error.message || 'Failed to create product' }); // Return detailed message
  }
});

router.put('/products/:id', async (req, res) => {
  try {
    const updatedProduct = await productApiHandlers.updateProduct(req.params.id, req.body);
    if (!updatedProduct) return res.status(404).json({ error: 'Product not found' });
    res.json(updatedProduct);
  } catch (error) {
    console.error(`❌ Failed to update product ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to update product' });
  }
});

router.delete('/products/:id', async (req, res) => {
  try {
    const success = await productApiHandlers.deleteProduct(req.params.id);
    if (!success) return res.status(404).json({ error: 'Product not found' });
    res.json({ success: true });
  } catch (error) {
    console.error(`❌ Failed to delete product ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to delete product' });
  }
});

//
// 🔹 INQUIRY ROUTES
//
router.get('/inquiries', async (req, res) => {
  try {
    const inquiries = await inquiryApiHandlers.getAllInquiries();
    res.json(inquiries);
  } catch (error) {
    console.error('❌ Failed to fetch inquiries:', error);
    res.status(500).json({ error: 'Failed to fetch inquiries' });
  }
});

router.post('/inquiries', async (req, res) => {
  try {
    const newInquiry = await inquiryApiHandlers.addInquiry(req.body);
    res.status(201).json(newInquiry);
  } catch (error) {
    console.error('❌ Failed to create inquiry:', error);
    res.status(500).json({ error: 'Failed to create inquiry' });
  }
});

router.patch('/inquiries/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const updatedInquiry = await inquiryApiHandlers.updateInquiryStatus(req.params.id, status);
    if (!updatedInquiry) return res.status(404).json({ error: 'Inquiry not found' });
    res.json(updatedInquiry);
  } catch (error) {
    console.error(`❌ Failed to update inquiry ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to update inquiry' });
  }
});

router.delete('/inquiries/:id', async (req, res) => {
  try {
    const success = await inquiryApiHandlers.deleteInquiry(req.params.id);
    if (!success) return res.status(404).json({ error: 'Inquiry not found' });
    res.json({ success: true });
  } catch (error) {
    console.error(`❌ Failed to delete inquiry ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to delete inquiry' });
  }
});

//
// 🔹 CONTACT SUBMISSION ROUTES
//
router.get('/contacts', async (req, res) => {
  try {
    const contacts = await contactApiHandlers.getContactSubmissions();
    res.json(contacts);
  } catch (error) {
    console.error('❌ Failed to fetch contact submissions:', error);
    res.status(500).json({ error: 'Failed to fetch contact submissions' });
  }
});

router.post('/contacts', async (req, res) => {
  try {
    const newContact = await contactApiHandlers.addContactSubmission(req.body);
    res.status(201).json(newContact);
  } catch (error) {
    console.error('❌ Failed to create contact submission:', error);
    res.status(500).json({ error: 'Failed to create contact submission' });
  }
});

router.patch('/contacts/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const updatedContact = await contactApiHandlers.updateContactSubmissionStatus(req.params.id, status);
    if (!updatedContact) return res.status(404).json({ error: 'Contact submission not found' });
    res.json(updatedContact);
  } catch (error) {
    console.error(`❌ Failed to update contact submission ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to update contact submission' });
  }
});

router.delete('/contacts/:id', async (req, res) => {
  try {
    const success = await contactApiHandlers.deleteContactSubmission(req.params.id);
    if (!success) return res.status(404).json({ error: 'Contact submission not found' });
    res.json({ success: true });
  } catch (error) {
    console.error(`❌ Failed to delete contact submission ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to delete contact submission' });
  }
});

export default router;
