import express from 'express';
import cors from 'cors';
import apiRoutes from './routes';
import { env } from './config/env';

const app = express();
const port = env.port;

// Middleware
app.use(cors());
app.use(express.json());

// API routes
app.use('/api', apiRoutes);

// Health check
app.get('/', (req, res) => {
  res.send('API is running...');
});

// Start server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

export default app;